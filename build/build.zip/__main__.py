# file: app/__main__.py

import command

@command.subcommand()
def nothing(args):
	'''This does nothing special'''
	print("Nothing special!")

@command.subcommand(command.argument("-d", help="Debug mode", action="store_true"), command.argument("-n", help="No mode", action="store_true"))
def test(args):
	if args.d:
		print(args.d)
	else:
		print(args)

@command.subcommand(command.argument("-f", "--filename", help="A thing with a filename"))
def filename(args):
    print(args.filename)

if __name__ == '__main__':
	command.parse()