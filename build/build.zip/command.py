# file: app/parser.py

from argparse import ArgumentParser

parser = ArgumentParser()
subparsers = parser.add_subparsers(dest="subcommand")

def argument(*name_or_flags, **kwargs):
	return name_or_flags, kwargs

def subcommand(*subparser_args, parent=subparsers):
	def decorator(func):
		parser = parent.add_parser(func.__name__, description=func.__doc__)
		for args, kwargs in subparser_args:
			parser.add_argument(*args, **kwargs)
		parser.set_defaults(func=func)
	return decorator

def parse():
	args = parser.parse_args()

	out = subparsers.choices
	
	#print(out)
	#for a in list(out):
	#	print(a)

	print(parser._positionals.title)

	if args.subcommand is None:
		parser.print_help()
	else:
		args.func(args)

def printHelp():
	parser.print_help()